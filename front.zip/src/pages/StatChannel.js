import React from 'react';
export default function StatChannel() {
  return <h1>유입 경로</h1>;
}
