// src/pages/Test.jsx
import React from 'react';

export default function Test() {
  return (
    <div style={{ padding: 20 }}>
      <h1>테스트 페이지</h1>
      <p>이곳에서 테스트용 콘텐츠를 확인할 수 있습니다.</p>
    </div>
  );
}
