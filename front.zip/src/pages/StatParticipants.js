// src/pages/StatEventDevices.jsx

export default function StatEventDevices() { 
<>
</>

}
