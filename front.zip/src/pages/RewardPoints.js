import React from 'react';
export default function RewardPoints() {
  return <h1>적립금</h1>;
}
