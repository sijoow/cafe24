import React from 'react';
export default function StatNewUsers() {
  return <h1>신규 회원</h1>;
}
