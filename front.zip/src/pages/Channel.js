// src/pages/Channel.jsx

export default function Channel() { 
    <>
    <div>123</div>
    </>
    
    }
