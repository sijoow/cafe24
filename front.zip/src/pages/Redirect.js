import React, { useEffect, useState } from 'react';

export default function Redirect() {
  { 
    return (
      <>
        <div>리다이렉트 페이지</div>
      </>
    )
  }
}
